# Rerbal Space Program: ☿ Mercury
*A game for 7DRL 2023, meant to recreate [KSP](https://www.kerbalspaceprogram.com/) as a Roguelike*

## FAQ

What's a "Rerbal"?

It's an alien species who are known to be roguish.

